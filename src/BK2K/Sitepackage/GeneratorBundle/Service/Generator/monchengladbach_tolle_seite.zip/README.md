Base Sitepackage for the project MonchengladbachTolleSeite
==============================================================

Add some explanation here.
